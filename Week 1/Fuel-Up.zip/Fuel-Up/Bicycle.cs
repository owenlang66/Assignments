public class Bicycle : Vehicle
{
    public Bicycle() : base ("Bicycle", 1, "red", false, 50)
    {
        
    }
}